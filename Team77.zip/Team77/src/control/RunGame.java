package control;

public class RunGame {

	public static void main(String[] args) {
		StartViewControl s = new StartViewControl();
	}

}