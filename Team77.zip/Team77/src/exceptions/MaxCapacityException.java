package exceptions;

@SuppressWarnings("serial")
public class MaxCapacityException extends ArmyException {

	public MaxCapacityException() {
		
	}

	public MaxCapacityException(String s) {
		super(s);
		
	}

}
